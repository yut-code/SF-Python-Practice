#PROJECT: PARSE A FILE

#Open favouritethings.txt and count the instances of each character (ignore case). Print the character with the max count and the character with the min count.
import string

# accessing text
file = open('favouritethings.txt', 'r')
fileText = file.read()
file.close()

# finding all lowercase characters in the text- no duplicates or spaces 
characters = set(fileText)
letters = [letter for letter in characters if letter in string.ascii_lowercase]
# creating a dictionary
dict = {}

# loop through all possible characters in the text and count how many instances a character/letter was used. created a key value pair as instances: character 
for letter in letters:
  instances = fileText.count(letter)
  dict[instances] = letter

# finding key with the max and min value 
max = max(dict.keys())
min = min(dict.keys())

print("Max Char: {} had count = {}".format(dict[max], max))
print("Min Char: {} had count = {}".format(dict[min], min))